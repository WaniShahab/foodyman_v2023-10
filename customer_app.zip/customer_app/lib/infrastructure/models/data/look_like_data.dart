class LookLikeData {
  final int index;
  final bool isLiking;

  LookLikeData({required this.index, required this.isLiking});
}
