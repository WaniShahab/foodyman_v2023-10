

class TabBarModel {
  final String name;
  final int count;
  double? height;

  TabBarModel({required this.name, required this.count,this.height,});
}