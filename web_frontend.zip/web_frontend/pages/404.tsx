import NotFound from "containers/notFound/notFound";
import React from "react";

type Props = {};

export default function PageNotFound({}: Props) {
  return <NotFound />;
}
