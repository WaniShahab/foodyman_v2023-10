const genders = [
  {
    label: "male",
    value: "1",
  },
  {
    label: "female",
    value: "2",
  },
];

export default genders;
