const categories = [
  {
    id: 0,
    title: "All",
  },
  {
    id: 1,
    title: "Burger",
  },
  {
    id: 2,
    title: "Salad",
  },
  {
    id: 3,
    title: "Pizza",
  },
  {
    id: 4,
    title: "Soup",
  },
  {
    id: 5,
    title: "Chicken",
  },
  {
    id: 6,
    title: "Japanese",
  },
];

export default categories;
