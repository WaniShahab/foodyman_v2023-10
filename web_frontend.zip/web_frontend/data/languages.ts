const languages = [
  {
    locale: "en",
    title: "English",
  },
  {
    locale: "ru",
    title: "Русский",
  },
  {
    locale: "uz",
    title: "O'zbek",
  },
];

export default languages;
