const allShops = [
  {
    id: 0,
    translation: {
      title: "Black star burger",
      locale: "en",
    },
    logo_img: "/images/black-star.png",
    background_img: "/images/shop5.jpeg",
  },
  {
    id: 1,
    translation: {
      title: "Urban curry",
      locale: "en",
    },
    logo_img: "/images/sultan-saray.png",
    background_img: "/images/shop6.jpeg",
  },
  {
    id: 2,
    translation: {
      title: "Just Wing It. by Fresco Inc",
      locale: "en",
    },
    logo_img: "/images/yaponamama.png",
    background_img: "/images/shop7.jpeg",
  },
  {
    id: 3,
    translation: {
      title: "Original Buffalo Wings ",
      locale: "en",
    },
    logo_img: "/images/basri-baba.png",
    background_img: "/images/shop8.jpeg",
  },
  {
    id: 4,
    translation: {
      title: "Black star burger",
      locale: "en",
    },
    logo_img: "/images/black-star.png",
    background_img: "/images/shop1.jpeg",
  },
  {
    id: 5,
    translation: {
      title: "Urban curry",
      locale: "en",
    },
    logo_img: "/images/sultan-saray.png",
    background_img: "/images/shop2.jpeg",
  },
  {
    id: 6,
    translation: {
      title: "Just Wing It. by Fresco Inc",
      locale: "en",
    },
    logo_img: "/images/yaponamama.png",
    background_img: "/images/shop3.jpeg",
  },
  {
    id: 7,
    translation: {
      title: "Original Buffalo Wings ",
      locale: "en",
    },
    logo_img: "/images/basri-baba.png",
    background_img: "/images/shop4.jpeg",
  },
  {
    id: 8,
    translation: {
      title: "Black star burger",
      locale: "en",
    },
    logo_img: "/images/black-star.png",
    background_img: "/images/shop5.jpeg",
  },
  {
    id: 9,
    translation: {
      title: "Urban curry",
      locale: "en",
    },
    logo_img: "/images/sultan-saray.png",
    background_img: "/images/shop6.jpeg",
  },
  {
    id: 10,
    translation: {
      title: "Just Wing It. by Fresco Inc",
      locale: "en",
    },
    logo_img: "/images/yaponamama.png",
    background_img: "/images/shop7.jpeg",
  },
  {
    id: 11,
    translation: {
      title: "Original Buffalo Wings ",
      locale: "en",
    },
    logo_img: "/images/basri-baba.png",
    background_img: "/images/shop8.jpeg",
  },
];

export default allShops;
