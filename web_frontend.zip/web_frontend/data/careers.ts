const careers = [
  {
    id: 1,
    title: "Sr Software engineer - Java",
    category: "Backend",
    location: "Washington, US",
  },
  {
    id: 2,
    title: "Software engineer - Java",
    category: "Backend",
    location: "Washington, US",
  },
  {
    id: 3,
    title: "Sr Flutter developer",
    category: "Mobile",
    location: "Washington, US",
  },
];

export default careers;
