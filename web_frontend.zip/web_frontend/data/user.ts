const user = {
  id: 11,
  firstname: "Katya",
  lastname: "Katya",
  img: "/images/avatar.png",
};

export default user;
