const currencies = [
  {
    value: "eur",
    title: "€",
  },
  {
    value: "usd",
    title: "$",
  },
  {
    value: "gbp",
    title: "£",
  },
];

export default currencies;
