const banners = [
  {
    id: 1,
    image: "/images/banner1.png",
    url: "/",
  },
  {
    id: 2,
    image: "/images/banner2.png",
    url: "/",
  },
  {
    id: 3,
    image: "/images/banner1.png",
    url: "/",
  },
];

export default banners;
